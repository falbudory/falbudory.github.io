# Mình mới up thêm file text mấy bạn thích copy code thì vào đó copy hết code rồi dán vào web như w3School hay mấy web chạy code khác sẽ không bị lỗi chữ nữa nha
